package tunnel

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"

	"ctunnel/pkg/catalog"
)

func iranTunnel(method, remote string) catalog.TunnelConfig {
	return catalog.TunnelConfig{Role: "iran", Method: method, LocalIP: "198.51.100.1", RemoteIP: remote}
}

func TestOneIranManyKharejGetDistinctSubnetsAndPorts(t *testing.T) {
	var all []catalog.TunnelConfig
	for i, remote := range []string{"203.0.113.1", "203.0.113.2", "203.0.113.3"} {
		tc := iranTunnel("dtls-1.3", remote)
		if i == 2 {
			tc.Method = "gre"
		}
		if err := Normalize(&tc, all); err != nil {
			t.Fatalf("tunnel %d: %v", i, err)
		}
		all = append(all, tc)
	}
	seenAddr, seenPort, seenName := map[string]bool{}, map[int]bool{}, map[string]bool{}
	for _, tc := range all {
		if seenAddr[tc.TunLocal4] || seenName[tc.Name] || (tc.Port > 0 && seenPort[tc.Port]) {
			t.Fatalf("collision in %+v", tc)
		}
		seenAddr[tc.TunLocal4], seenName[tc.Name], seenPort[tc.Port] = true, true, true
	}
	if all[0].TunLocal4 != "10.77.1.1" || all[1].TunLocal4 != "10.77.2.1" || all[1].Port != 24002 {
		t.Fatalf("unexpected allocation: %+v / %+v", all[0], all[1])
	}
	if all[2].Port != 0 || all[2].GREKey != 0 {
		t.Fatalf("plain GRE must be keyless and without FOU for MikroTik compatibility: %+v", all[2])
	}
}

func TestFOUPortCollisionRejected(t *testing.T) {
	first := iranTunnel("gre", "203.0.113.1")
	first.Port = 5555
	if err := Normalize(&first, nil); err != nil {
		t.Fatal(err)
	}
	second := iranTunnel("gre", "203.0.113.2")
	second.Index, second.Port = 2, 5555
	if err := Normalize(&second, []catalog.TunnelConfig{first}); err == nil {
		t.Fatal("two GRE FOU tunnels on the same UDP port were accepted")
	}
}

func TestVXLANCanShareDefaultPort(t *testing.T) {
	first := iranTunnel("vxlan", "203.0.113.1")
	if err := Normalize(&first, nil); err != nil {
		t.Fatal(err)
	}
	second := iranTunnel("vxlan", "203.0.113.2")
	second.Index = 2
	if err := Normalize(&second, []catalog.TunnelConfig{first}); err != nil {
		t.Fatalf("VXLAN tunnels must share 4789 by VNI: %v", err)
	}
	if first.Port != 4789 || second.Port != 4789 {
		t.Fatalf("unexpected VXLAN ports: %d %d", first.Port, second.Port)
	}
}

func TestDuplicateForwardPortRejected(t *testing.T) {
	tc := iranTunnel("gre", "203.0.113.1")
	tc.Ports = []string{"443", "443=8443"}
	if err := Normalize(&tc, nil); err == nil {
		t.Fatal("duplicate listen port accepted")
	}
}

func TestNormalizeTrimsAddresses(t *testing.T) {
	tc := iranTunnel("gre", " 203.0.113.1 ")
	tc.LocalIP = " 198.51.100.1 "
	tc.TunLocal4, tc.TunRemote4 = " 10.77.9.1 ", " 10.77.9.2 "
	if err := Normalize(&tc, nil); err != nil {
		t.Fatal(err)
	}
	for _, v := range []string{tc.LocalIP, tc.RemoteIP, tc.TunLocal4, tc.TunRemote4} {
		if strings.TrimSpace(v) != v {
			t.Fatalf("address kept whitespace: %q", v)
		}
	}
}

func TestSaveStopsExistingBeforeEnvRewrite(t *testing.T) {
	dir := t.TempDir()
	st, err := catalog.LoadStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	orig := Run
	var calls []string
	Run = func(name string, args ...string) (string, error) {
		calls = append(calls, name+" "+strings.Join(args, " "))
		if name == "systemctl" && len(args) > 0 && args[0] == "is-active" {
			return "inactive", errors.New("inactive")
		}
		return "active", nil
	}
	t.Cleanup(func() { Run = orig })

	tc := iranTunnel("gre", "203.0.113.1")
	tc.Name = "t1"
	if err := Create(st, &tc); err != nil {
		t.Fatal(err)
	}
	tc.Method, tc.Port = "ipip", 0
	if err := Save(st, &tc); err != nil {
		t.Fatal(err)
	}
	want := "systemctl disable --now ctunnel@t1.service"
	found := false
	for _, call := range calls {
		if call == want {
			found = true
		}
	}
	if !found {
		t.Fatalf("old service was not stopped before env rewrite: %v", calls)
	}
	env, err := ParseEnv(EnvPath(dir, "t1"))
	if err != nil || env["KIND"] != "ipip" {
		t.Fatalf("env was not rewritten: %v %v", env, err)
	}
}

func TestRemoveRefusesActiveService(t *testing.T) {
	dir := t.TempDir()
	st, err := catalog.LoadStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	tc := iranTunnel("gre", "203.0.113.1")
	tc.Name = "t1"
	if err := Create(st, &tc); err != nil {
		t.Fatal(err)
	}
	orig := Run
	Run = func(name string, args ...string) (string, error) {
		if name == "systemctl" && len(args) > 0 && args[0] == "is-active" {
			return "", nil
		}
		return "active", nil
	}
	t.Cleanup(func() { Run = orig })

	if err := Remove(st, "t1"); err == nil {
		t.Fatal("remove deleted a tunnel whose service was still active")
	}
	st2, err := catalog.LoadStore(dir)
	if err != nil || len(st2.Tunnels) != 1 {
		t.Fatalf("state was deleted after a failed teardown: %v %v", st2, err)
	}
}

func TestApplyRefusesActiveOldUnit(t *testing.T) {
	orig := Run
	Run = func(name string, args ...string) (string, error) {
		if name == "systemctl" && len(args) > 0 {
			switch args[0] {
			case "disable":
				return "busy", errors.New("busy")
			case "is-active":
				return "", nil
			}
		}
		return "active", nil
	}
	t.Cleanup(func() { Run = orig })
	tc := catalog.TunnelConfig{Name: "t1", Method: "gre", Reverse: true}
	if err := Apply(tc); err == nil {
		t.Fatal("Apply started the new unit while the old one was still active")
	}
}

func TestPeerSideMirrorsIranSide(t *testing.T) {
	tc := iranTunnel("6to4", "203.0.113.9")
	tc.Ports = []string{"443", "2053=8443"}
	if err := Normalize(&tc, nil); err != nil {
		t.Fatal(err)
	}
	link, _ := catalog.EncodeSetupLink(tc)
	peer, err := catalog.DecodeSetupLink(link)
	if err != nil {
		t.Fatal(err)
	}
	if err := Normalize(&peer, nil); err != nil {
		t.Fatal(err)
	}
	if peer.TunLocal4 != tc.TunRemote4 || peer.CarrierLocal6 != tc.CarrierRemote6 || peer.MTU != tc.MTU {
		t.Fatalf("peer does not mirror: %+v vs %+v", peer, tc)
	}
	if len(peer.Ports) != 0 {
		t.Fatal("kharej side must not forward ports")
	}
}

func TestCollisionsRejected(t *testing.T) {
	a := iranTunnel("dtls-1.3", "203.0.113.1")
	_ = Normalize(&a, nil)
	a.Ports = []string{"443"}
	b := iranTunnel("quic-v1", "203.0.113.2")
	b.Port = a.Port
	if err := Normalize(&b, []catalog.TunnelConfig{a}); err == nil || !strings.Contains(err.Error(), "port") {
		t.Fatalf("shared UDP port accepted: %v", err)
	}
	c := iranTunnel("gre", "203.0.113.3")
	c.Ports = []string{"443"}
	if err := Normalize(&c, []catalog.TunnelConfig{a}); err == nil {
		t.Fatal("same forwarded port on two tunnels accepted")
	}
	d := iranTunnel("gre", "203.0.113.4")
	d.Index = a.Index
	if err := Normalize(&d, []catalog.TunnelConfig{a}); err == nil {
		t.Fatal("same subnet index accepted")
	}
}

func TestInvalidInputRejected(t *testing.T) {
	cases := map[string]func(*catalog.TunnelConfig){
		"bad ip":      func(tc *catalog.TunnelConfig) { tc.RemoteIP = "1.2.3.4; rm -rf /" },
		"long name":   func(tc *catalog.TunnelConfig) { tc.Name = "averyverylongname" },
		"bad token":   func(tc *catalog.TunnelConfig) { tc.Token = "$(id)" },
		"bad forward": func(tc *catalog.TunnelConfig) { tc.Ports = []string{"70000"} },
		"v4 for ip6":  func(tc *catalog.TunnelConfig) { tc.Method = "ip6gre" },
	}
	for name, mutate := range cases {
		tc := iranTunnel("gre", "203.0.113.1")
		mutate(&tc)
		if err := Normalize(&tc, nil); err == nil {
			t.Errorf("%s: accepted", name)
		}
	}
}

func TestMTULeavesRoomForPadding(t *testing.T) {
	tc := iranTunnel("dtls-1.3", "203.0.113.1")
	_ = Normalize(&tc, nil)
	m, _ := catalog.LookupMethod("dtls-1.3")
	if tc.MTU+m.Overhead+tc.Padding > 1500 {
		t.Fatalf("MTU %d + overhead %d + padding %d exceeds 1500", tc.MTU, m.Overhead, tc.Padding)
	}
}

func TestEnvRoundTripAndKeys(t *testing.T) {
	tc := iranTunnel("wireguard", "203.0.113.1")
	if err := Normalize(&tc, nil); err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	if err := WriteEnv(dir, tc); err != nil {
		t.Fatal(err)
	}
	env, err := ParseEnv(filepath.Join(dir, "tunnels", tc.Name+".env"))
	if err != nil {
		t.Fatal(err)
	}
	if env["DEV"] != "ct-"+tc.Name || env["REMOTE_IP"] != tc.RemoteIP || env["SECRET"] != tc.Token {
		t.Fatalf("env mismatch: %v", env)
	}
	_, kharejPub := WireGuardKeys(tc.Token, "kharej")
	if env["WG_PEER_PUBLIC"] != kharejPub || env["WG_PRIVATE"] == "" {
		t.Fatal("wireguard peer key does not match the kharej side")
	}
}

func TestReverseTunnelPassiveIranAndMirroredKharej(t *testing.T) {
	// In reverse mode on Iran, UDP-Crypt and WireGuard do not even require knowing Kharej's IP in advance.
	tc := catalog.TunnelConfig{
		Role:    "iran",
		Method:  "dtls-1.3",
		LocalIP: "198.51.100.1",
		Reverse: true,
		Ports:   []string{"443"},
	}
	if err := Normalize(&tc, nil); err != nil {
		t.Fatalf("reverse iran Normalize failed: %v", err)
	}
	if tc.RemoteIP != "0.0.0.0" {
		t.Fatalf("expected default 0.0.0.0 RemoteIP for passive reverse iran, got %q", tc.RemoteIP)
	}
	envStr := Env(tc)
	if !strings.Contains(envStr, `REVERSE="1"`) {
		t.Fatalf("expected REVERSE=\"1\" in env, got:\n%s", envStr)
	}

	// Setup link decoded on Kharej must preserve Reverse=true and point RemoteIP to Iran's LocalIP.
	link, err := catalog.EncodeSetupLink(tc)
	if err != nil {
		t.Fatal(err)
	}
	peer, err := catalog.DecodeSetupLink(link)
	if err != nil {
		t.Fatal(err)
	}
	peer.LocalIP = "203.0.113.55" // Kharej fills its own local IP if needed
	if err := Normalize(&peer, nil); err != nil {
		t.Fatalf("reverse kharej Normalize failed: %v", err)
	}
	if !peer.Reverse || peer.Role != "kharej" || peer.RemoteIP != "198.51.100.1" {
		t.Fatalf("unexpected reverse kharej config: %+v", peer)
	}
}

func TestReverseKernelTunnelUsesReverseCarrierAndCustomLocalIPs(t *testing.T) {
	// 1. Reverse GRE tunnel on Iran without RemoteIP gets 0.0.0.0, port 24001, and ctunnel-engine@ unit.
	greRev := catalog.TunnelConfig{
		Role:       "iran",
		Method:     "gre",
		LocalIP:    "198.51.100.1",
		Reverse:    true,
		TunLocal4:  "10.88.1.1",
		TunRemote4: "10.88.10.2",
	}
	if err := Normalize(&greRev, nil); err != nil {
		t.Fatalf("reverse GRE Normalize failed: %v", err)
	}
	if greRev.RemoteIP != "0.0.0.0" || greRev.Port != 24001 {
		t.Fatalf("expected RemoteIP=0.0.0.0 and Port=24001 for reverse GRE, got %+v", greRev)
	}
	if got := Unit(greRev); got != "ctunnel-engine@ir-24001.service" {
		t.Fatalf("expected ctunnel-engine@ir-24001.service for reverse GRE, got %q", got)
	}

	// 2. A second tunnel on the same Iran server can reuse the same TunLocal4 (10.88.1.1) with a different TunRemote4.
	greRev2 := catalog.TunnelConfig{
		Role:       "iran",
		Method:     "6to4",
		LocalIP:    "198.51.100.1",
		Reverse:    true,
		TunLocal4:  "10.88.1.1",
		TunRemote4: "10.88.20.2",
	}
	if err := Normalize(&greRev2, []catalog.TunnelConfig{greRev}); err != nil {
		t.Fatalf("second tunnel sharing TunLocal4 with distinct TunRemote4 failed: %v", err)
	}
	if greRev2.TunLocal4 != "10.88.1.1" || greRev2.TunRemote4 != "10.88.20.2" {
		t.Fatalf("custom local tunnel IPs were overwritten: %+v", greRev2)
	}
}

func TestReverseWireGuardUsesKernelService(t *testing.T) {
	for _, role := range []string{"iran", "kharej"} {
		tc := catalog.TunnelConfig{Name: "t1", Method: "wireguard", Role: role, Reverse: true}
		if got := Unit(tc); got != "ctunnel@t1.service" {
			t.Fatalf("reverse WireGuard must use kernel unit, got %s", got)
		}
		if got := otherUnit(tc); got != "ctunnel-engine@t1.service" {
			t.Fatalf("old incorrect engine unit must be disabled, got %s", got)
		}
	}
}

func TestConcurrentWriteEnvHasUniqueTemporaryFiles(t *testing.T) {
	dir := t.TempDir()
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			tc := iranTunnel("gre", "203.0.113.1")
			tc.Name, tc.Token = "t1", fmt.Sprintf("%064x", i+1)
			for j := 0; j < 4; j++ {
				if err := WriteEnv(dir, tc); err != nil {
					t.Error(err)
					return
				}
				env, err := ParseEnv(EnvPath(dir, "t1"))
				if err != nil || len(env["SECRET"]) != 64 {
					t.Errorf("partial env: %v %v", env, err)
					return
				}
			}
		}(i)
	}
	wg.Wait()
	files, err := os.ReadDir(EnvDir(dir))
	if err != nil || len(files) != 1 || files[0].Name() != "t1.env" {
		t.Fatalf("temporary file leak: %v %v", files, err)
	}
	if runtime.GOOS != "windows" {
		info, err := os.Stat(EnvPath(dir, "t1"))
		if err != nil || info.Mode().Perm() != 0600 {
			t.Fatalf("env permissions: %v %v", info, err)
		}
	}
}

func TestDefaultNameCarriesSideAndPort(t *testing.T) {
	cases := []struct {
		tc   catalog.TunnelConfig
		want string
	}{
		{catalog.TunnelConfig{Role: "iran", Method: "dtls-1.3", RemoteIP: "203.0.113.5", LocalIP: "198.51.100.1"}, "ir-24001"},
		{catalog.TunnelConfig{Role: "kharej", Method: "dtls-1.3", RemoteIP: "198.51.100.1", LocalIP: "203.0.113.5", Token: "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"}, "kh-24001"},
		{catalog.TunnelConfig{Role: "iran", Method: "gre", Reverse: true, LocalIP: "198.51.100.1", Index: 12}, "ir-24012"},
		{catalog.TunnelConfig{Role: "iran", Method: "gre", RemoteIP: "203.0.113.5", LocalIP: "198.51.100.1", Ports: []string{"2053=8443", "443"}}, "ir-2053"},
		{catalog.TunnelConfig{Role: "iran", Method: "gre", RemoteIP: "203.0.113.5", LocalIP: "198.51.100.1", Index: 3}, "ir-t3"},
		{catalog.TunnelConfig{Role: "iran", Method: "dtls-1.3", RemoteIP: "203.0.113.5", LocalIP: "198.51.100.1", Index: 250, Port: 65535}, "ir-65535"},
		{catalog.TunnelConfig{Name: "edge", Role: "iran", Method: "dtls-1.3", RemoteIP: "203.0.113.5", LocalIP: "198.51.100.1"}, "edge"},
	}
	for _, c := range cases {
		tc := c.tc
		if err := Normalize(&tc, nil); err != nil {
			t.Fatalf("%+v: %v", c.tc, err)
		}
		if tc.Name != c.want {
			t.Errorf("name = %q, want %q", tc.Name, c.want)
		}
		if len("ct-"+tc.Name+".7") > 15 {
			t.Errorf("%s overflows the interface name limit", tc.Name)
		}
	}
}

func TestDefaultNameAvoidsTakenName(t *testing.T) {
	other := catalog.TunnelConfig{Name: "ir-443", Index: 1}
	tc := catalog.TunnelConfig{Role: "iran", Index: 2, Ports: []string{"443"}}
	if got := DefaultName(tc, []catalog.TunnelConfig{other}); got != "ir-t2" {
		t.Fatalf("got %q", got)
	}
}

func TestMirrorNameForTheOtherEnd(t *testing.T) {
	for _, c := range [][3]string{{"ir-24001", "kharej", "kh-24001"}, {"kh-t3", "iran", "ir-t3"}, {"ir-24001", "iran", "ir-24001"}, {"edge", "kharej", "edge"}} {
		if got := MirrorName(c[0], c[1]); got != c[2] {
			t.Errorf("MirrorName(%q, %q) = %q, want %q", c[0], c[1], got, c[2])
		}
	}
}

func TestGetStatusesUsesOneSystemctlCall(t *testing.T) {
	orig := Run
	t.Cleanup(func() { Run = orig })
	calls := 0
	Run = func(name string, args ...string) (string, error) {
		calls++
		return "active\nfailed\ninactive", errors.New("exit status 3")
	}
	tcs := []catalog.TunnelConfig{{Name: "ir-1", Method: "gre"}, {Name: "ir-2", Method: "dtls-1.3"}, {Name: "ir-3", Method: "gre"}}
	got := GetStatuses(tcs)
	if calls != 1 || got[0].Service != "active" || got[1].Service != "failed" || got[2].Service != "inactive" {
		t.Fatalf("calls=%d statuses=%+v", calls, got)
	}
	// A short answer (old systemd, bus error) falls back to one call per unit.
	calls = 0
	Run = func(string, ...string) (string, error) { calls++; return "active", nil }
	if got = GetStatuses(tcs); calls != 4 || got[2].Service != "active" {
		t.Fatalf("fallback calls=%d statuses=%+v", calls, got)
	}
}

func TestNormalizeLayer4(t *testing.T) {
	iran := catalog.TunnelConfig{Role: "iran", Method: "wssmux", LocalIP: "198.51.100.1", Ports: []string{"443", "2053=8443"}, SNI: "cdn.example.com"}
	if err := Normalize(&iran, nil); err != nil {
		t.Fatal(err)
	}
	if !iran.Reverse || iran.Port != 3080+iran.Index || iran.MTU != 0 || iran.RemoteIP != "0.0.0.0" || iran.SNI != "cdn.example.com" {
		t.Fatalf("iran end: %+v", iran)
	}
	if env := Env(iran); !strings.Contains(env, `SNI="cdn.example.com"`) || !strings.Contains(env, `FORWARDS="443 2053=8443"`) {
		t.Fatalf("env:\n%s", env)
	}

	kharej := catalog.TunnelConfig{Role: "kharej", Method: "tcpmux", LocalIP: "203.0.113.5", RemoteIP: "198.51.100.1", Port: 3081, Token: "a long secret phrase", SNI: "x.example"}
	if err := Normalize(&kharej, nil); err != nil {
		t.Fatal(err)
	}
	if !kharej.Reverse || kharej.Port != 3081 || kharej.SNI != "" || len(kharej.Token) != 64 {
		t.Fatalf("kharej end: %+v", kharej)
	}

	bad := []catalog.TunnelConfig{
		{Role: "iran", Method: "tcp", LocalIP: "198.51.100.1", Port: 4000, Ports: []string{"4000"}},
		{Role: "iran", Method: "tcp", LocalIP: "198.51.100.1", BackupMethod: "gre"},
		{Role: "iran", Method: "ws", LocalIP: "198.51.100.1", SNI: "bad host!"},
	}
	for _, b := range bad {
		if err := Normalize(&b, nil); err == nil {
			t.Fatalf("accepted %+v", b)
		}
	}
}

func TestNormalizeStealth(t *testing.T) {
	ping := catalog.TunnelConfig{Role: "iran", Method: "icmp", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5", Port: 5000}
	if err := Normalize(&ping, nil); err != nil {
		t.Fatal(err)
	}
	if ping.Port != 0 || ping.Padding != DefaultPad || ping.MTU != 1500-53-DefaultPad {
		t.Fatalf("icmp: port %d padding %d mtu %d", ping.Port, ping.Padding, ping.MTU)
	}
	rev := catalog.TunnelConfig{Role: "iran", Method: "icmp", LocalIP: "198.51.100.1", Reverse: true}
	if err := Normalize(&rev, nil); err != nil || rev.Port != 0 {
		t.Fatalf("icmp reverse: port %d, %v", rev.Port, err)
	}

	fake := catalog.TunnelConfig{Role: "iran", Method: "faketcp", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5", Padding: 64}
	if err := Normalize(&fake, nil); err != nil || fake.Port == 0 || fake.Padding != 64 {
		t.Fatalf("faketcp: %+v %v", fake, err)
	}
}

func TestLookAlikesTakeTheRealPortWhenFree(t *testing.T) {
	for method, want := range map[string]int{"stun-turn": 3478, "gtp-u": 2152, "esp-udp": 4500} {
		first := catalog.TunnelConfig{Role: "kharej", Method: method, LocalIP: "203.0.113.5", RemoteIP: "198.51.100.1", Index: 1}
		if err := Normalize(&first, nil); err != nil || first.Port != want {
			t.Fatalf("%s: port %d, want %d (%v)", method, first.Port, want, err)
		}
		second := catalog.TunnelConfig{Role: "kharej", Method: method, LocalIP: "203.0.113.5", RemoteIP: "198.51.100.2", Index: 2}
		if err := Normalize(&second, []catalog.TunnelConfig{first}); err != nil || second.Port == want || second.Port == 0 {
			t.Fatalf("%s second tunnel: port %d (%v)", method, second.Port, err)
		}
	}
}

func TestLayer4FailoverNeedsALayer4Backup(t *testing.T) {
	ok := catalog.TunnelConfig{Role: "iran", Method: "wssmux", LocalIP: "198.51.100.1", BackupMethod: "udpmux", Index: 2}
	if err := Normalize(&ok, nil); err != nil {
		t.Fatalf("wssmux with a udpmux backup: %v", err)
	}
	b, err := BackupConfig(ok)
	if err != nil || b.Method != "udpmux" || b.Port == 0 || !b.Reverse {
		t.Fatalf("backup config: %+v %v", b, err)
	}
	for _, bad := range []catalog.TunnelConfig{
		{Role: "iran", Method: "tcp", LocalIP: "198.51.100.1", BackupMethod: "gre"},
		{Role: "iran", Method: "gre", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5", BackupMethod: "udpmux"},
	} {
		if err := Normalize(&bad, nil); err == nil {
			t.Fatalf("accepted %s with backup %s", bad.Method, bad.BackupMethod)
		}
	}
}

func TestDirectL4PortConflict(t *testing.T) {
	first := catalog.TunnelConfig{
		Role: "kharej", Method: "tcp", DirectL4: true,
		LocalIP: "203.0.113.5", Port: 3081, Index: 1,
	}
	if err := Normalize(&first, nil); err != nil {
		t.Fatal(err)
	}
	second := catalog.TunnelConfig{
		Role: "kharej", Method: "tcp", DirectL4: true,
		LocalIP: "203.0.113.5", Port: 3081, Index: 2,
	}
	if err := Normalize(&second, []catalog.TunnelConfig{first}); err == nil {
		t.Fatal("two Direct L4 TCP tunnels on the same port 3081 were accepted")
	}
}

func TestPerformanceProfilesEcoTurboHyper(t *testing.T) {
	// Direct core L3 (gre): ECO = raw kernel (Carrier=false), TURBO & HYPER = BBR Carrier (Carrier=true).
	eco := catalog.TunnelConfig{Role: "iran", Method: "gre", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Normalize(&eco, nil); err != nil {
		t.Fatal(err)
	}
	if eco.Profile != catalog.ProfileEco || eco.Carrier {
		t.Fatalf("default gre should be eco/non-carrier: %+v", eco)
	}
	if !strings.Contains(Env(eco), `PROFILE="eco"`) {
		t.Fatalf("Env missing PROFILE=eco: %s", Env(eco))
	}

	turbo := catalog.TunnelConfig{Role: "iran", Method: "gre", Profile: "turbo", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Normalize(&turbo, nil); err != nil {
		t.Fatal(err)
	}
	if turbo.Profile != catalog.ProfileTurbo || !turbo.Carrier || turbo.Port == 0 || Unit(turbo) != "ctunnel-engine@"+turbo.Name+".service" {
		t.Fatalf("turbo Direct gre must activate BBR TCP carrier: %+v unit=%s", turbo, Unit(turbo))
	}

	hyper := catalog.TunnelConfig{Role: "iran", Method: "xgre", Profile: "hyper", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Normalize(&hyper, nil); err != nil {
		t.Fatal(err)
	}
	if hyper.Profile != catalog.ProfileHyper || !hyper.Carrier || !strings.Contains(Env(hyper), `PROFILE="hyper"`) {
		t.Fatalf("hyper Direct xgre failed: %+v", hyper)
	}

	// Legacy turbo+gre (Carrier=true, Profile="") preserves turbo & Carrier=true.
	legacyTurbo := catalog.TunnelConfig{Role: "iran", Method: "gre", Carrier: true, LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Normalize(&legacyTurbo, nil); err != nil {
		t.Fatal(err)
	}
	if legacyTurbo.Profile != catalog.ProfileTurbo || !legacyTurbo.Carrier {
		t.Fatalf("legacy Carrier=true tunnel lost turbo mode: %+v", legacyTurbo)
	}

	// MikroTik L2 (eoip, vxlan) does NOT turn on Carrier on TURBO/HYPER.
	eoipHyper := catalog.TunnelConfig{Role: "iran", Method: "eoip", Profile: "hyper", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Normalize(&eoipHyper, nil); err != nil {
		t.Fatal(err)
	}
	if eoipHyper.Carrier || eoipHyper.Profile != catalog.ProfileHyper {
		t.Fatalf("eoip hyper must stay raw MikroTik-compatible without Carrier: %+v", eoipHyper)
	}

	// Invalid profile rejected.
	bad := catalog.TunnelConfig{Role: "iran", Method: "tcp", Profile: "warp9", LocalIP: "198.51.100.1"}
	if err := Normalize(&bad, nil); err == nil {
		t.Fatal("invalid profile accepted")
	}
}

func TestLegacyMethodBlockedOnCreateAllowedOnManage(t *testing.T) {
	dir := t.TempDir()
	st, err := catalog.LoadStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	orig := Run
	Run = func(name string, args ...string) (string, error) {
		if name == "systemctl" && len(args) > 0 && args[0] == "is-active" {
			return "inactive", fmt.Errorf("inactive")
		}
		return "", nil
	}
	t.Cleanup(func() { Run = orig })

	// Creating a new legacy tunnel must fail.
	wgNew := catalog.TunnelConfig{Role: "iran", Method: "wireguard", LocalIP: "198.51.100.1", RemoteIP: "203.0.113.5"}
	if err := Create(st, &wgNew); err == nil {
		t.Fatal("Create accepted legacy method wireguard")
	}
	// Creating reverse frp+ on non-SupportsFRP (eoip, vxlan) must fail.
	frpEoip := catalog.TunnelConfig{Role: "iran", Method: "eoip", Reverse: true, LocalIP: "198.51.100.1"}
	if err := Create(st, &frpEoip); err == nil {
		t.Fatal("Create accepted reverse frp+ on eoip")
	}
	// Creating reverse frp+ on core L3 (xgre) succeeds.
	frpXgre := catalog.TunnelConfig{Role: "iran", Method: "xgre", Reverse: true, LocalIP: "198.51.100.1"}
	if err := Create(st, &frpXgre); err != nil {
		t.Fatalf("Create rejected frp+xgre: %v", err)
	}
	// Existing legacy tunnel in store remains fully manageable via Save & UpdateProfile.
	existing := catalog.TunnelConfig{
		Name: "oldwg", Role: "iran", Method: "wireguard", Index: 5,
		LocalIP: "198.51.100.1", RemoteIP: "203.0.113.9", Port: 51825,
		Token: catalog.GenerateToken(),
	}
	if err := Save(st, &existing); err != nil {
		t.Fatalf("Save rejected existing legacy tunnel: %v", err)
	}
	updated, err := UpdateProfile(st, "oldwg", "hyper")
	if err != nil || updated.Profile != catalog.ProfileHyper {
		t.Fatalf("UpdateProfile on legacy tunnel failed: %+v %v", updated, err)
	}
}

func TestStealthTCPAndWSConfig(t *testing.T) {
	// Direct stealth-ws on Kharej is passive (RemoteIP optional) and allows SNI.
	kh := catalog.TunnelConfig{
		Role: "kharej", Method: "stealth-ws", LocalIP: "203.0.113.5",
		SNI: "cdn.example.com", Profile: "turbo",
	}
	if err := Normalize(&kh, nil); err != nil {
		t.Fatalf("stealth-ws kharej direct failed: %v", err)
	}
	if !IsPassivePeer(kh) || kh.RemoteIP != "0.0.0.0" || kh.SNI != "cdn.example.com" || Unit(kh) != "ctunnel-engine@"+kh.Name+".service" {
		t.Fatalf("unexpected stealth-ws config: %+v", kh)
	}
	// Reverse stealth-tcp on Iran is passive and clears SNI.
	ir := catalog.TunnelConfig{
		Role: "iran", Method: "stealth-tcp", Reverse: true, LocalIP: "198.51.100.1",
		SNI: "ignored.example.com", Profile: "hyper",
	}
	if err := Normalize(&ir, nil); err != nil {
		t.Fatalf("stealth-tcp iran reverse failed: %v", err)
	}
	if !IsPassivePeer(ir) || ir.RemoteIP != "0.0.0.0" || ir.SNI != "" || ir.Port == 0 {
		t.Fatalf("unexpected stealth-tcp config: %+v", ir)
	}
	// Bad SNI rejected on stealth-ws.
	badSNI := catalog.TunnelConfig{
		Role: "iran", Method: "stealth-ws", Reverse: true, LocalIP: "198.51.100.1",
		SNI: "bad host;rm -rf /",
	}
	if err := Normalize(&badSNI, nil); err == nil {
		t.Fatal("malicious SNI accepted on stealth-ws")
	}
}

func TestImportL4AutoResolvesIndexAndDialOnlyPort(t *testing.T) {
	dir := t.TempDir()
	origRun := Run
	Run = func(name string, args ...string) (string, error) { return "", nil }
	t.Cleanup(func() { Run = origRun })

	st, err := catalog.LoadStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	// Two separate Iran servers both create L4 ws tunnels on index 1 & port 3081.
	ir1 := catalog.TunnelConfig{
		Name: "ir-3081", Role: "iran", Method: "ws", Reverse: true, Index: 1, Port: 3081,
		LocalIP: "198.51.100.1", RemoteIP: "203.0.113.10", Token: catalog.GenerateToken(),
	}
	ir2 := catalog.TunnelConfig{
		Name: "ir-3081", Role: "iran", Method: "ws", Reverse: true, Index: 1, Port: 3081,
		LocalIP: "198.51.100.2", RemoteIP: "203.0.113.10", Token: catalog.GenerateToken(),
	}
	link1, err := catalog.EncodeSetupLink(ir1)
	if err != nil {
		t.Fatal(err)
	}
	link2, err := catalog.EncodeSetupLink(ir2)
	if err != nil {
		t.Fatal(err)
	}

	kh1, err := catalog.DecodeSetupLink(link1)
	if err != nil {
		t.Fatal(err)
	}
	if err := Import(st, &kh1); err != nil {
		t.Fatalf("first L4 import failed: %v", err)
	}
	kh2, err := catalog.DecodeSetupLink(link2)
	if err != nil {
		t.Fatal(err)
	}
	if err := Import(st, &kh2); err != nil {
		t.Fatalf("second L4 import with colliding index/port/name failed: %v", err)
	}
	if kh2.Index == kh1.Index || kh2.Name == kh1.Name {
		t.Fatalf("expected distinct index & name on kharej, got kh1=(%s,%d) kh2=(%s,%d)", kh1.Name, kh1.Index, kh2.Name, kh2.Index)
	}
	if kh2.Port != 3081 {
		t.Fatalf("expected second L4 tunnel to preserve remote dial port 3081, got %d", kh2.Port)
	}
}

func TestReassignIndexUpdatesDerivedSubnets(t *testing.T) {
	tc := catalog.TunnelConfig{
		Name: "ir-xgre", Role: "iran", Method: "xgre", Index: 1,
		LocalIP: "198.51.100.1", RemoteIP: "203.0.113.10", Token: catalog.GenerateToken(),
	}
	if err := Normalize(&tc, nil); err != nil {
		t.Fatal(err)
	}
	ReassignIndex(&tc, 7)
	if err := Normalize(&tc, nil); err != nil {
		t.Fatal(err)
	}
	if tc.Index != 7 || tc.TunLocal4 != "10.77.7.1" || tc.TunRemote4 != "10.77.7.2" || tc.GREKey != 7*16 {
		t.Fatalf("unexpected reassigned config: %+v", tc)
	}
}

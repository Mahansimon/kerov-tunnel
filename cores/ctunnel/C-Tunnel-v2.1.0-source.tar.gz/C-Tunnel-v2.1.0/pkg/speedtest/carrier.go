package speedtest

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"ctunnel/pkg/tcpmss"
)

// The carrier test speaks the same wire shape as the REVERSE TCP carrier of
// ctunnel-engine: parallel TCP streams carrying TLS 1.2 application-data records
// [0x17 0x03 0x03 len] with random-looking bodies. A path that throttles or resets
// that shape shows it here, before a reverse tunnel is built on it.
const (
	recordType     = 0x17
	CarrierStreams = 8
	carrierRecord  = 16 << 10
)

func writeRecord(w io.Writer, body []byte) error {
	var hdr [5]byte
	hdr[0], hdr[1], hdr[2] = recordType, 0x03, 0x03
	binary.BigEndian.PutUint16(hdr[3:], uint16(len(body)))
	if err := writeFull(w, hdr[:]); err != nil {
		return err
	}
	return writeFull(w, body)
}

func writeFull(w io.Writer, b []byte) error {
	for len(b) > 0 {
		n, err := w.Write(b)
		if err != nil {
			return err
		}
		if n <= 0 || n > len(b) {
			return io.ErrShortWrite
		}
		b = b[n:]
	}
	return nil
}

func readRecord(r io.Reader, buf []byte) (int, error) {
	var hdr [5]byte
	if _, err := io.ReadFull(r, hdr[:]); err != nil {
		return 0, err
	}
	if hdr[0] != recordType || hdr[1] != 0x03 || hdr[2] != 0x03 {
		return 0, errors.New("not a record")
	}
	n := int(binary.BigEndian.Uint16(hdr[3:]))
	if n == 0 || n > len(buf) {
		return 0, errors.New("record too large")
	}
	_, err := io.ReadFull(r, buf[:n])
	return n, err
}

// serveCarrier handles one carrier test stream; the first header byte is already read.
func serveCarrier(c net.Conn) {
	var rest [4]byte
	if _, err := io.ReadFull(c, rest[:]); err != nil || rest[0] != 0x03 || rest[1] != 0x03 {
		return
	}
	n := int(binary.BigEndian.Uint16(rest[2:]))
	if n < 1 || n > 1024 {
		return
	}
	hello := make([]byte, n)
	if _, err := io.ReadFull(c, hello); err != nil {
		return
	}
	_ = c.SetDeadline(time.Now().Add(20 * time.Second))
	prefix, err := carrierPrefix(hello)
	if err != nil {
		return
	}
	switch hello[0] {
	case 'P': // latency probe: echo records back
		buf := make([]byte, 1024)
		if err := writeRecord(c, hello); err != nil {
			return
		}
		for {
			n, err := readRecord(c, buf)
			if err != nil || writeRecord(c, buf[:n]) != nil {
				return
			}
		}
	case 'D':
		body := make([]byte, carrierRecord)
		_, _ = rand.Read(body)
		copy(body, prefix)
		for writeRecord(c, body) == nil {
		}
	case 'U':
		var total atomic.Uint64
		stopAck, ackDone := make(chan struct{}), make(chan struct{})
		go func() {
			defer close(ackDone)
			tk := time.NewTicker(ctSpeedAckEvery)
			defer tk.Stop()
			var sent uint64
			var ack [8]byte
			for {
				select {
				case <-stopAck:
					return
				case <-tk.C:
				}
				if n := total.Load(); n != sent {
					binary.BigEndian.PutUint64(ack[:], n)
					if writeRecord(c, ack[:]) != nil {
						return
					}
					sent = n
				}
			}
		}()
		buf := make([]byte, 64<<10)
		for {
			n, err := readRecord(c, buf)
			if err != nil {
				break
			}
			if !bytes.HasPrefix(buf[:n], prefix) {
				break
			}
			total.Add(uint64(n - len(prefix)))
		}
		close(stopAck)
		<-ackDone
		var finalAck [8]byte
		binary.BigEndian.PutUint64(finalAck[:], total.Load())
		_ = writeRecord(c, finalAck[:])
	}
}

func dialCarrier(ctx context.Context, addr string, mode byte, prefix []byte) (net.Conn, error) {
	if len(prefix) > 512 {
		return nil, errors.New("carrier prefix too long")
	}
	c, err := (&net.Dialer{Timeout: 3 * time.Second, Control: tcpmss.ControlBBR}).DialContext(ctx, "tcp", addr)
	if err != nil {
		return nil, err
	}
	if tc, ok := c.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
	}
	hello := make([]byte, 32)
	_, _ = rand.Read(hello)
	hello[0] = mode
	if len(prefix) > 0 {
		hello = append([]byte{mode, 'C', 'T', 'M', '1', byte(len(prefix) >> 8), byte(len(prefix))}, prefix...)
	}
	_ = c.SetDeadline(time.Now().Add(5 * time.Second))
	if err := writeRecord(c, hello); err != nil {
		_ = c.Close()
		return nil, err
	}
	return c, nil
}

// carrierPrefix preserves compatibility with old 32-byte random hellos.
func carrierPrefix(hello []byte) ([]byte, error) {
	if len(hello) < 5 || string(hello[1:5]) != "CTM1" {
		return nil, nil
	}
	if len(hello) < 7 {
		return nil, errors.New("truncated method hello")
	}
	n := int(binary.BigEndian.Uint16(hello[5:7]))
	if n == 0 || n > 512 || len(hello) != 7+n {
		return nil, errors.New("invalid method hello")
	}
	return hello[7:], nil
}

// CarrierRTT probes the legacy aggregate carrier.
func CarrierRTT(ctx context.Context, addr string, probes int, interval time.Duration) []float64 {
	return CarrierPayloadRTT(ctx, addr, nil, probes, interval)
}

// CarrierPayloadRTT verifies full echoes, including the method-specific prefix.
func CarrierPayloadRTT(ctx context.Context, addr string, prefix []byte, probes int, interval time.Duration) []float64 {
	return CarrierPayloadRTTLive(ctx, addr, prefix, probes, interval, nil)
}

// CarrierPayloadRTTLive verifies echoes step-by-step and emits progress samples.
func CarrierPayloadRTTLive(ctx context.Context, addr string, prefix []byte, probes int, interval time.Duration, onStep func(sent int, rtts []float64)) []float64 {
	c, err := dialCarrier(ctx, addr, 'P', prefix)
	if err != nil {
		return nil
	}
	defer c.Close()
	stop := context.AfterFunc(ctx, func() { _ = c.Close() })
	defer stop()
	buf := make([]byte, 1024)
	if _, err = readRecord(c, buf); err != nil {
		return nil
	}
	var rtts []float64
	body := make([]byte, len(prefix)+64)
	copy(body, prefix)
	for i := 0; i < probes && ctx.Err() == nil; i++ {
		_, _ = rand.Read(body[len(prefix):])
		_ = c.SetDeadline(time.Now().Add(1500 * time.Millisecond))
		t0 := time.Now()
		if writeRecord(c, body) != nil {
			if onStep != nil {
				onStep(i+1, rtts)
			}
			break
		}
		n, err := readRecord(c, buf)
		if err != nil || !bytes.Equal(body, buf[:n]) {
			if onStep != nil {
				onStep(i+1, rtts)
			}
			break
		}
		rtts = append(rtts, float64(time.Since(t0).Microseconds())/1000)
		if onStep != nil {
			onStep(i+1, rtts)
		}
		if !sleepCtx(ctx, interval) {
			break
		}
	}
	return rtts
}

// MeasureCarrier measures download (server → client) and upload over CarrierStreams
// record-framed TCP streams, counting only bytes the receiver got.
func MeasureCarrier(ctx context.Context, addr string, warmup, duration time.Duration) (down, up float64, err error) {
	return MeasureCarrierPayload(ctx, addr, nil, warmup, duration)
}

// MeasureCarrierPayload runs fresh streams for one method, counting verified payload bytes.
func MeasureCarrierPayload(ctx context.Context, addr string, prefix []byte, warmup, duration time.Duration) (down, up float64, err error) {
	return MeasureCarrierPayloadLive(ctx, addr, prefix, warmup, duration, nil)
}

// MeasureCarrierPayloadLive runs fresh streams for one method and emits ~200ms
// rolling-window samples, measuring upload first then download to match NeoTunnel.
func MeasureCarrierPayloadLive(ctx context.Context, addr string, prefix []byte, warmup, duration time.Duration, onSample func(dir byte, mbps float64)) (down, up float64, err error) {
	if warmup < 0 || duration <= 0 {
		return 0, 0, errors.New("invalid measurement duration")
	}
	if up, err = carrierDirection(ctx, addr, 'U', prefix, warmup, duration, onSample); err != nil {
		return 0, 0, err
	}
	down, err = carrierDirection(ctx, addr, 'D', prefix, warmup, duration, onSample)
	return down, up, err
}

func carrierDirection(parent context.Context, addr string, dir byte, prefix []byte, warmup, duration time.Duration, onSample func(dir byte, mbps float64)) (float64, error) {
	ctx, cancel := context.WithCancel(parent)
	defer cancel()
	var conns []net.Conn
	for i := 0; i < CarrierStreams; i++ {
		c, err := dialCarrier(ctx, addr, dir, prefix)
		if err != nil {
			for _, c := range conns {
				_ = c.Close()
			}
			return 0, err
		}
		conns = append(conns, c)
	}
	defer func() {
		for _, c := range conns {
			_ = c.Close()
		}
	}()
	var got atomic.Uint64
	var failed atomic.Bool
	var wg sync.WaitGroup
	defer func() { cancel(); wg.Wait() }()
	for _, c := range conns {
		_ = c.SetDeadline(time.Now().Add(warmup + duration + 3*time.Second))
		wg.Add(1)
		go func(c net.Conn) {
			defer wg.Done()
			go func() { <-ctx.Done(); _ = c.Close() }()
			buf := make([]byte, 64<<10)
			if dir == 'D' {
				for {
					n, err := readRecord(c, buf)
					if err != nil || !bytes.HasPrefix(buf[:n], prefix) {
						if ctx.Err() == nil {
							failed.Store(true)
						}
						return
					}
					got.Add(uint64(n - len(prefix)))
				}
			}
			body := make([]byte, carrierRecord)
			_, _ = rand.Read(body)
			copy(body, prefix)
			go func() {
				for ctx.Err() == nil && writeRecord(c, body) == nil {
				}
			}()
			var prior uint64
			for {
				n, err := readRecord(c, buf)
				if err != nil || n != 8 {
					if ctx.Err() == nil {
						failed.Store(true)
					}
					return
				}
				if v := binary.BigEndian.Uint64(buf[:8]); v > prior {
					got.Add(v - prior)
					prior = v
				}
			}
		}(c)
	}
	readLive := got.Load
	if dir == 'U' {
		readLive = func() uint64 {
			if acked, ok := sumTCPAcked(conns); ok && acked > 0 {
				return acked
			}
			return got.Load()
		}
	}
	if !sampleWindow(ctx, warmup, readLive, func(mbps float64) {
		if onSample != nil {
			onSample(dir, mbps)
		}
	}) {
		return 0, ctx.Err()
	}
	base, t0 := got.Load(), time.Now()
	if !sampleWindow(ctx, duration, readLive, func(mbps float64) {
		if onSample != nil {
			onSample(dir, mbps)
		}
	}) {
		return 0, ctx.Err()
	}
	total, el := got.Load()-base, time.Since(t0).Seconds()
	cancel()
	wg.Wait()
	if failed.Load() || total == 0 {
		return 0, fmt.Errorf("carrier %c stream failed or returned no verified payload", dir)
	}
	finalMbps := float64(total) * 8 / el / 1e6
	if onSample != nil {
		onSample(dir, finalMbps)
	}
	return finalMbps, nil
}

type windowSample struct {
	bytes uint64
	at    time.Time
}

func sumTCPAcked(conns []net.Conn) (uint64, bool) {
	var total uint64
	anyOK := false
	for _, c := range conns {
		if n, ok := tcpAcked(c); ok {
			total += n
			anyOK = true
		}
	}
	return total, anyOK
}

// sampleWindow samples cumulative delivered bytes at 200ms intervals and emits
// the moving throughput over the trailing ~1-second window (5 ticks).
func sampleWindow(ctx context.Context, d time.Duration, readBytes func() uint64, emit func(mbps float64)) bool {
	_, ok := sampleWindowPeak(ctx, d, readBytes, emit)
	return ok
}

// sampleWindowPeak samples cumulative delivered bytes at 200ms intervals, emits
// moving throughput over the trailing ~1-second window, and returns the highest
// whole-second window rate observed during the span.
func sampleWindowPeak(ctx context.Context, d time.Duration, readBytes func() uint64, emit func(mbps float64)) (float64, bool) {
	if d <= 0 {
		return 0, ctx.Err() == nil
	}
	if readBytes == nil {
		return 0, sleepCtx(ctx, d)
	}
	end := time.Now().Add(d)
	tick := time.NewTicker(200 * time.Millisecond)
	defer tick.Stop()
	ring := []windowSample{{bytes: readBytes(), at: time.Now()}}
	var peak float64
	step := func(now time.Time) {
		cur := readBytes()
		last := ring[len(ring)-1].bytes
		if cur < last {
			cur = last
		}
		ring = append(ring, windowSample{bytes: cur, at: now})
		if len(ring) > 6 {
			ring = ring[len(ring)-6:]
		}
		first := ring[0]
		if dt := now.Sub(first.at).Seconds(); dt > 0 && cur >= first.bytes {
			mbps := float64(cur-first.bytes) * 8 / dt / 1e6
			if dt >= 0.9 && mbps > peak {
				peak = mbps
			}
			if emit != nil {
				emit(mbps)
			}
		}
	}
	for {
		rem := time.Until(end)
		if rem <= 0 {
			return peak, true
		}
		select {
		case <-ctx.Done():
			return peak, false
		case <-time.After(rem):
			step(time.Now())
			return peak, true
		case now := <-tick.C:
			step(now)
		}
	}
}

func sleepSample(ctx context.Context, d time.Duration, counter *atomic.Uint64, emit func(mbps float64)) bool {
	if counter == nil {
		return sleepCtx(ctx, d)
	}
	return sampleWindow(ctx, d, counter.Load, emit)
}

func sleepCtx(ctx context.Context, d time.Duration) bool {
	select {
	case <-ctx.Done():
		return false
	case <-time.After(d):
		return true
	}
}

// ctunnel is the management CLI: interactive menu, web panel and helper commands.
package main

import (
	"context"
	"ctunnel/pkg/agent"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"ctunnel/pkg/catalog"
	"ctunnel/pkg/cli"
	"ctunnel/pkg/conntest"
	"ctunnel/pkg/localproxy"
	"ctunnel/pkg/speedtest"
	"ctunnel/pkg/tunnel"
	"ctunnel/pkg/version"
	"ctunnel/pkg/webpanel"
)

func main() {
	if len(os.Args) < 2 {
		cli.RunInteractiveMenu()
		return
	}
	args := os.Args[2:]
	switch strings.ToLower(os.Args[1]) {
	case "menu":
		cli.RunInteractiveMenu()

	case "status", "list":
		cli.StatusTable()

	case "up", "restart", "down", "link":
		if len(args) != 1 {
			log.Fatalf("usage: ctunnel %s <name>", os.Args[1])
		}
		tunnelCommand(os.Args[1], args[0])

	case "set-peer":
		setPeerCommand(args)

	case "set-profile":
		setProfileCommand(args)

	case "apply-link":
		if len(args) != 1 {
			log.Fatal("usage: ctunnel apply-link 'ctunnel://...'")
		}
		applyLink(args[0])

	case "conntest":
		fs := flag.NewFlagSet("conntest", flag.ExitOnError)
		only := fs.String("only", "", "test only these methods, comma separated (e.g. udp,udpmux,icmp)")
		newOnly := fs.Bool("new", false, "test only the methods new in 2.0")
		_ = fs.Parse(args)
		if fs.NArg() != 1 {
			log.Fatal("usage: ctunnel conntest [-new | -only m1,m2] 'ctunnel-test://...'   (get the link with: ctunnel conntest-server on the iran server)")
		}
		var methods []string
		if *newOnly {
			methods = conntest.NewMethods
		}
		methods = append(methods, cli.SplitMethods(*only)...)
		if err := cli.RunConnTest(fs.Arg(0), methods); err != nil {
			log.Fatal(err)
		}

	case "conntest-server":
		host := ""
		if len(args) > 0 {
			host = args[0]
		}
		cli.ConnTestServer(host)

	case "linktest":
		fs := flag.NewFlagSet("linktest", flag.ExitOnError)
		port := fs.Int("port", speedtest.DefaultSpeedPort, "responder port")
		_ = fs.Parse(args)
		if fs.NArg() != 1 {
			log.Fatal("usage: ctunnel linktest [-port N] <host>")
		}
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		fmt.Print(speedtest.Format(speedtest.Run(ctx, net.JoinHostPort(fs.Arg(0), strconv.Itoa(*port)), 20)))

	case "speedtest-server":
		fs := flag.NewFlagSet("speedtest-server", flag.ExitOnError)
		port := fs.Int("port", speedtest.DefaultSpeedPort, "TCP port to listen on")
		_ = fs.Parse(args)
		addr, _, err := speedtest.StartServer(fmt.Sprintf(":%d", *port))
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("link test responder listening on %s", addr)
		select {}

	case "catalog", "methods":
		showAll := len(args) > 0 && (args[0] == "-all" || args[0] == "--all")
		for _, m := range catalog.Methods {
			if m.Legacy && !showAll {
				continue
			}
			tag := ""
			if m.Legacy {
				tag = " [legacy]"
			}
			fmt.Printf("%2d  %-13s %-10s %s%s\n", m.ID, m.Name, m.Family, m.Title, tag)
		}

	case "panel":
		fs := flag.NewFlagSet("panel", flag.ExitOnError)
		port := fs.Int("port", 0, "listen port (default: the port saved in state.json)")
		_ = fs.Parse(args)
		st, err := catalog.LoadStore(cli.StoreDir)
		if err != nil {
			log.Fatal(err)
		}
		if *port == 0 {
			*port = st.PanelPort
		}
		srv := webpanel.NewServer(cli.StoreDir, fmt.Sprintf(":%d", *port))
		address, err := webpanel.PanelURL(cli.StoreDir, "<server-ip>", *port)
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("web panel on %s", address)
		log.Fatal(srv.ListenAndServe())

	case "restart-all":
		ok, failed := cli.RestartAll()
		fmt.Printf("restarted %d tunnels (%d failed)\n", ok, failed)
		if failed > 0 {
			os.Exit(1)
		}

	case "agent":
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
		defer stop()
		agent.Run(ctx, cli.StoreDir)

	case "proxy-serve":
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
		defer stop()
		localproxy.Run(ctx)

	case "optimize":
		if err := tunnel.Optimize(); err != nil {
			log.Fatal(err)
		}

	case "version", "-v", "--version":
		fmt.Println("ctunnel", version.Version)

	default:
		fmt.Print(`Usage: ctunnel [command]

  (no command)                 interactive menu
  status                       tunnel table with state and traffic
  up|restart|down <name>       start, restart or stop a tunnel
  set-peer <name> <ip>         change peer IP (Iran IP on Kharej / Kharej IP on Iran) and restart
  set-peer -all <old> <new>    replace peer IP on every tunnel matching <old> and restart
  set-profile <name> <tier>    switch performance profile (auto | eco | turbo | hyper) and restart
  link <name>                  print the setup link for the other server
  apply-link 'ctunnel://...'   create and start the tunnel from a link
  conntest-server [ip]         iran side of the connection test: prints a link
  conntest [-new|-only a,b] 'ctunnel-test://…'  kharej side: which methods pass, speed, recommendation
  linktest [-port N] <host>    latency, loss and speed to <host>
  speedtest-server [-port N]   responder for linktest (default 7711/tcp)
  panel [-port N]              run the web panel in the foreground
  restart-all                  restart every tunnel (Auto Refresh runs this)
  agent                        benchmark responder and failover (its service runs this)
  proxy-serve                  run the built-in SOCKS5/HTTP proxy (its service runs this)
  optimize                     apply BBR and buffer tuning
  catalog                      list tunnel methods
  version
`)
	}
}

func tunnelCommand(cmd, name string) {
	st, err := catalog.LoadStore(cli.StoreDir)
	if err != nil {
		log.Fatal(err)
	}
	tc, ok := st.Find(name)
	if !ok {
		log.Fatalf("tunnel %q not found", name)
	}
	switch cmd {
	case "up", "restart":
		err = tunnel.Apply(tc)
	case "down":
		_, err = tunnel.Run("systemctl", "stop", tunnel.Unit(tc))
	case "link":
		var link string
		link, err = catalog.EncodeSetupLink(tc)
		if err == nil {
			fmt.Println(link)
			if cmdLine := catalog.OneLineInstallCommand(link); cmdLine != "" {
				fmt.Println("\n# One-line install & connect on the other server:\n" + cmdLine)
			}
			if mk := tunnel.MikroTik(tc); mk != "" {
				fmt.Println("\n# MikroTik peer (RouterOS 7):\n" + mk)
			}
		}
	}
	if err != nil {
		log.Fatal(err)
	}
}

func setPeerCommand(args []string) {
	fs := flag.NewFlagSet("set-peer", flag.ExitOnError)
	all := fs.Bool("all", false, "replace peer IP on all tunnels currently matching <old-ip>")
	_ = fs.Parse(args)
	if fs.NArg() != 2 {
		log.Fatal("usage: ctunnel set-peer <name> <new-ip>  |  ctunnel set-peer -all <old-ip> <new-ip>")
	}
	st, err := catalog.LoadStore(cli.StoreDir)
	if err != nil {
		log.Fatal(err)
	}
	if *all {
		oldIP, newIP := fs.Arg(0), fs.Arg(1)
		updated, err := tunnel.UpdatePeerMatching(st, oldIP, newIP, "")
		if err != nil {
			log.Fatal(err)
		}
		var failed int
		for _, tc := range updated {
			if err := tunnel.Apply(tc); err != nil {
				log.Printf("%s: restart failed: %v", tc.Name, err)
				failed++
			} else {
				fmt.Printf("%s (%s): %s -> %s (restarted)\n", tc.Name, tc.Role, oldIP, tc.RemoteIP)
			}
		}
		if failed > 0 {
			os.Exit(1)
		}
		return
	}
	name, newIP := fs.Arg(0), fs.Arg(1)
	tc, oldIP, err := tunnel.UpdatePeer(st, name, newIP)
	if err != nil {
		log.Fatal(err)
	}
	if err := tunnel.Apply(tc); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%s (%s): %s %s -> %s (restarted)\n", tc.Name, tc.Role, tunnel.PeerRoleLabel(tc.Role), oldIP, tc.RemoteIP)
}

func setProfileCommand(args []string) {
	if len(args) != 2 {
		log.Fatal("usage: ctunnel set-profile <name> <auto|eco|turbo|hyper>")
	}
	st, err := catalog.LoadStore(cli.StoreDir)
	if err != nil {
		log.Fatal(err)
	}
	tc, err := tunnel.UpdateProfile(st, args[0], args[1])
	if err != nil {
		log.Fatal(err)
	}
	if err := tunnel.Apply(tc); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%s (%s): performance profile -> %s (restarted)\n", tc.Name, tc.Method, tunnel.DisplayProfile(tc))
}

func applyLink(link string) {
	tc, err := catalog.DecodeSetupLink(link)
	if err != nil {
		log.Fatal(err)
	}
	st, err := catalog.LoadStore(cli.StoreDir)
	if err != nil {
		log.Fatal(err)
	}
	if err := tunnel.Import(st, &tc); err != nil {
		log.Fatal(err)
	}
	if err := tunnel.Apply(tc); err != nil {
		log.Fatal(err)
	}
	cli.PrintTunnelConnected(tc)
}
